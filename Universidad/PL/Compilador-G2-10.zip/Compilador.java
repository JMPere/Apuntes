import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Compilador extends AnasintBaseListener{
    FileWriter fichero;
    String nombre_fichero=null;
    private int identacion=0;
    private int tabulacion=3;
    private Boolean exitBucle=true;
    private Boolean solo_asig=true;
    private Boolean solo_iter=false;
    private Boolean solo_cond=true;
    private int cuenta_cond=0;
    private int cuenta_bucle=0;
    private Integer cuenta_iter=0;

    private Integer count_instr=0;
    private  Integer count_dev=0;
    Map<String, Map<String, Object>> almacen_variables=new HashMap<>();//Nombre, tipo ("NUM","LOG"...), valor

    private void aumentoTabulacion(){
        identacion+=tabulacion;
    }
    private void decrementoTabulacion(){
        identacion-=tabulacion;
    }
    public void init(String f){
        nombre_fichero=new String(f);
    }
    private void abrirFichero(){
        try{
            fichero= new FileWriter("src/"+nombre_fichero+".java");
        }catch(IOException e){
            System.out.println("Error abrirFichero: No se ha podido abrir el fichero de salida\n");
            System.out.println(e);
        }
    }
    private void cerrarFichero(){
        try{
            fichero.close();
        }catch(IOException e){
            System.out.println("Error al cerrar el archivo\n");
            System.out.println(e);
        }
    }
    //Introducción de variables en mapa-almacen
    public void declarar_variable(String nombres, String t){

        Map<String, Object>m=new HashMap<>();
        System.out.println(nombres+" - "+t);
        if(nombres.contains(",")){
            String[]ls=nombres.split(",");
            for(String s:ls){
                if(t.contains("SEQ")){
                    if(t.contains("NUM")){
                        m.put(t,new ArrayList<Integer>());
                        almacen_variables.put(s,m);
                    }else{
                        m.put(t,new ArrayList<Boolean>());
                        almacen_variables.put(s,m);
                    }
                }else{
                    if(t.contains("NUM")){
                        m.put(t,null);
                        almacen_variables.put(s,m);
                    }else{
                        m.put(t,false);
                        almacen_variables.put(s,m);
                    }
                }
            }
        }else{
            if(t.contains("SEQ")){
                if(t.contains("NUM")){
                    m.put(t,new ArrayList<Integer>());
                    almacen_variables.put(nombres,m);
                }else{
                    m.put(t,new ArrayList<Boolean>());
                    almacen_variables.put(nombres,m);
                }
            }else{
                if(t.contains("NUM")){
                    m.put(t,0);
                    almacen_variables.put(nombres,m);
                }else{
                    m.put(t,false);
                    almacen_variables.put(nombres,m);
                }
            }
        }
    }
    //actualiza el valor de las variables suponiendo que no hay tipo LOG
    private void actualiza_variables(String instruccion){
        instruccion=instruccion.substring(0,instruccion.length()-1);
        String[]aux=instruccion.split("=");
        if(aux[1].contains(",")){
            String[]valor=aux[1].split(",");
            if(aux[0].contains(",")){
                String[]variable=aux[0].split(",");
                for(int i=0;i<variable.length;i++){
                    Map<String, Object>m=new HashMap<String, Object>();
                    m.put("NUM",valor[i]);
                    almacen_variables.put(variable[i],m);
                }
            }else{
                System.out.println("Error actualiza_variables: no puede asignarse varios valores a una sola variable");
            }
        }else{
            if(aux[0].contains(",")){
                String[]variable=aux[0].split(",");
                for(String s:variable){
                    Map<String, Object>m=new HashMap<String, Object>();
                    m.put("NUM",aux[1]);
                    almacen_variables.put(s,m);
                }
            }else{
                Map<String, Object>m=new HashMap<String, Object>();
                m.put("NUM",aux[1]);
                almacen_variables.put(aux[0],m);
            }
        }
    }
    private void gencode_espacios(){
        try{
            for (int i = 1; i<=identacion;i++)
                fichero.write(" ");
        }catch(IOException e){
            System.out.println("Error gencode_espacios: error al escribir espacios en blanco en fichero de salida "+e.toString());
        }
    }
    private void gencode_begin_class(){
        try{
            gencode_espacios();
            fichero.write("import java.io.*;\nimport java.util.List;\n");
            fichero.write("import java.util.ArrayList;\n");
            gencode_espacios();
            fichero.write("public class "+nombre_fichero+"{\n");
            aumentoTabulacion();
        }catch(IOException e){
            System.out.println("Error gencode_begin_class: Error al comienzo del programa; no se ha podido crear la clase");
        }
    }
     //Generar código fin clase
    private void gencode_end_class(){
        try{
            decrementoTabulacion();
            fichero.write("}");
        }catch(IOException e){
            System.out.println("Error gencode_end_class: error al cerrar la clase");
        }
    }
    private void gencode_begin_main(){
        try{
            gencode_espacios();
            fichero.write("public static void main(String[] args) {\n");
            aumentoTabulacion();
        }catch(IOException e){
            System.out.println("Error gencode_begin_main: error al generar el código de comienzo del main");
        }
    }

    //Generar código fin main
    private void gencode_end_main(){
        try{
            decrementoTabulacion();
            gencode_espacios();
            fichero.write("}\n");
        }catch(IOException e){
            System.out.println("Error gencode_end_main: error al cerrar el main");
        }
    }

    private void gencode_declarar_variables(){
        Map<String, String>nombre_tipo=new HashMap<>();

        for(String s:almacen_variables.keySet()){
            for(String t: almacen_variables.get(s).keySet()){
                nombre_tipo.put(s,t);
            }
        }
        if (nombre_tipo.keySet().size()>0){
            Set<String> set_num=new HashSet<>();
            Set<String>set_boo=new HashSet<>();
            Set<String>set_lnu=new HashSet<>();
            Set<String>set_lbo=new HashSet<>();
            for(String s:nombre_tipo.keySet()){
                String tipo=nombre_tipo.get(s);
                //System.out.println(s+" - "+tipo);
                if(tipo.contains("NUM")&&!tipo.contains("SEQ")){
                    set_num.add(s);
                }else if(tipo.contains("LOG")&&!tipo.contains("SEQ")){
                    set_boo.add(s);
                }else if(tipo.contains("SEQ")){
                    if(tipo.contains("NUM")){
                        set_lnu.add(s);
                    }else{
                        set_lbo.add(s);
                    }
                }
            }

            if(!set_boo.isEmpty()){
                gencode_espacios();
                gencode_escritura_declaracion("Boolean ",set_boo, false);
            }
            if(!set_num.isEmpty()){
                gencode_espacios();
                gencode_escritura_declaracion("Integer ",set_num, false);
            }
            if(!set_lbo.isEmpty()){
                gencode_espacios();
                gencode_escritura_declaracion("List<Boolean> ",set_lbo, true);
            }
            if(!set_lnu.isEmpty()){
                gencode_espacios();
                gencode_escritura_declaracion("List<Integer> ",set_lnu, true);
            }
        }
    }
    //Declaración de variables
    public void gencode_escritura_declaracion(String s, Set<String>ss, Boolean b){

        try{
            fichero.write(s);
            int comas=0;
            for (String v:ss) {
                if(comas<ss.size()-1){
                    fichero.write(v+",");
                    comas++;
                }else{
                    fichero.write(v);
                }
            }
            if(b){
                fichero.write(" = new ArrayList<>()");
            }
            fichero.write(";\n");
        } catch (IOException e) {
            System.out.println("Error gencode_escritura_declaracion: error al declarar las variables");
        }
    }
    //Generar codigo de la asignacion
    public void gencode_asignacion(String s){
        try {
            if(!s.contains("=")){
                //es dev
                if(s.startsWith("dev")){
                    gencode_espacios();
                    fichero.write("System.out.print("+s.substring(3,s.length()-1)+");\n");
                }
            }else {
                String[] dato = s.split("=");
                String variables = dato[0];
                String valores = dato[1].substring(0, dato[1].length() - 1);
                //comas en derecha e izquierda
                if (variables.contains(",") && valores.contains(",") && !valores.contains("[")) {
                    String[] var = variables.split(",");
                    String[] val = valores.split(",");
                    for (int i = 0; i < var.length; i++) {
                        gencode_espacios();
                        fichero.write(var[i] + " = " + val[i] + ";\n");
                    }
                } else if (variables.contains(",") && valores.contains("]")) {
                    String[] var = variables.split(",");
                    //si es tipo lista
                    if (valores.contains("],")) {
                        String[] lis = valores.split("],");
                        for (int i = 0; i < var.length - 1; i++) {
                            if (lis[i].contains("[")) {
                                lis[i] = lis[i].substring(1, lis[i].length());
                            }
                            if (lis[i].contains("]")) {
                                lis[i] = lis[i].substring(0, lis[i].length() - 1);
                            }
                            String[] aux = lis[i].split(",");
                            for (String a : aux) {
                                gencode_espacios();
                                fichero.write(var[0] + ".add(" + a + ");\n");
                            }
                        }
                    }//no es lista
                    else {
                        String[] val = valores.split(",");
                        for (String v : var) {
                            for (String l : val) {
                                gencode_espacios();
                                fichero.write(v + " = " + l + ";\n");
                            }
                        }
                    }
                }//comas a la izquierda pero no a la derecha
                else if (variables.contains(",")) {
                    String[] var = variables.split(",");
                    for (String v : var) {
                        gencode_espacios();
                        fichero.write(v + " = " + valores + ";\n");
                    }
                }//un solo valor a la izquierda
                else {
                    //lista a la derecha
                    if (valores.contains(",")) {
                        valores = valores.substring(1, valores.length() - 1);
                        String[] val = valores.split(",");
                        for (String v : val) {
                            gencode_espacios();
                            fichero.write(variables + ".add(" + v + ");\n");
                        }
                    }//entero a la derecha
                    else {
                        gencode_espacios();
                        fichero.write(variables + " = " + valores + ";\n");
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error gencode_instrucciones: error al escribir instrucciones en fichero de salida "+e.toString());
        }
    }

    public void gencode_condicional(String condicional){
        try{
            switch(condicional) {
                case "":
                    if(cuenta_cond>0){
                        solo_cond=false;
                    }else{
                        solo_cond=true;
                    }
                    break;
                default:
                    String resto = condicional;
                    if (resto.charAt(0) == 's' && resto.charAt(1) == 'i'&&resto.charAt(2)!='n') {
                        cuenta_cond+=1;
                        gencode_espacios();
                        condicional=condicional.substring(2,condicional.length());
                        String[] div_entonces = condicional.split("entonces");
                        fichero.write("if" + div_entonces[0] + "{\n");
                        aumentoTabulacion();
                        resto = condicional.substring(div_entonces[0].length()+8, condicional.length());
                        gencode_condicional(resto);
                    } else if (resto.charAt(0) == 'f' && resto.charAt(1) == 's' && resto.charAt(2) == 'i') {
                        decrementoTabulacion();
                        gencode_espacios();
                        fichero.write("}\n");
                        resto = resto.substring(3, resto.length());
                        gencode_condicional(resto);
                    }else if(resto.charAt(0)=='s'&&resto.charAt(1)=='i'&&resto.charAt(2)=='n'&&resto.charAt(3)=='o'){
                        decrementoTabulacion();
                        gencode_espacios();
                        fichero.write("}else{\n");
                        aumentoTabulacion();
                        resto=resto.substring(4,resto.length());
                        gencode_condicional(resto);
                    }else if(resto.charAt(0)=='r'&&resto.charAt(1)=='u'&&resto.charAt(2)=='p'&&resto.charAt(3)=='t'&&
                            resto.charAt(4)=='u'&&resto.charAt(5)=='r'&&resto.charAt(6)=='a'){
                        gencode_espacios();
                        fichero.write("break;\n");
                        resto=resto.substring(8,resto.length());
                        gencode_condicional(resto);
                    }else if(resto.charAt(0)=='d'&&resto.charAt(1)=='e'&&resto.charAt(2)=='v'){
                        gencode_espacios();
                        resto=resto.substring(3,resto.length());
                        String[]res=resto.split(";");
                        fichero.write("System.out.println("+res[0]+");\n");
                        resto=resto.substring(1,resto.length());
                        gencode_condicional(resto);
                    }else if(resto.charAt(0)=='m'&&resto.charAt(1)=='i'&&resto.charAt(2)=='e'&&resto.charAt(3)=='n'&&
                            resto.charAt(4)=='t'&&resto.charAt(5)=='r'&&resto.charAt(6)=='a'&&resto.charAt(7)=='s'){
                        //mientras dentro de if
                        String[]sigue=resto.split("fmientras");
                        int i=sigue.length-1;
                        String mientras=resto.substring(0,resto.length()-sigue[i].length());
                        System.out.println("cond iter: "+mientras);
                        gencode_iteracion(mientras);
                        resto=resto.substring(mientras.length(),resto.length());
                        gencode_condicional(resto);
                    }
                    else{

                        String[]instr=resto.split(";");
                        String asig=instr[0]+";";
                        gencode_asignacion(asig);
                        resto=resto.substring(asig.length(),resto.length());
                        gencode_condicional(resto);
                    }
            }
        }catch (IOException e) {
            System.out.println("Error gencode_condicional: error al escribir el condicional "+e.toString());
        }
    }


    public void enterPrograma(Anasint.ProgramaContext ctx) {
        abrirFichero();
        gencode_begin_class();
        gencode_begin_main();
    }
    public void exitPrograma(Anasint.ProgramaContext ctx) {
        System.out.println(almacen_variables);
        gencode_end_main();
        gencode_end_class();
        cerrarFichero();
    }

    public void enterVariables(Anasint.VariablesContext ctx) {
        for(Anasint.Vars_declaContext c:ctx.vars_decla()){
            declarar_variable(c.nom_var().getText(),c.tipo().getText());
        }
    }
    public void exitVariables(Anasint.VariablesContext ctx) {
        gencode_declarar_variables();
    }

    @Override
    public void enterAsignacion(Anasint.AsignacionContext ctx) {
        if(count_instr==0&&solo_asig){
            gencode_asignacion(ctx.getText());
            actualiza_variables(ctx.getText());
        }
        if(count_instr!=0){
            count_instr--;
        }

    }

    @Override
    public void enterCondicional(Anasint.CondicionalContext ctx) {
        if(solo_cond) {
            solo_asig=false;
            gencode_condicional(ctx.getText());
        }
    }

    @Override
    public void exitCondicional(Anasint.CondicionalContext ctx) {
        cuenta_bucle+=1;
        if(cuenta_bucle==cuenta_cond){
            cuenta_cond=0;
            cuenta_bucle=0;
            solo_asig=true;
        }
    }

    @Override
    public void enterIteracion(Anasint.IteracionContext ctx) {

        if(cuenta_iter!=0){
            cuenta_iter--;
            System.out.println("bloques bloqueados: "+cuenta_iter+" : "+ctx.getText());
        }else{
            gencode_iteracion(ctx.getText());
            System.out.println(count_instr);
        }

    }

    @Override
    public void enterDevolucion(Anasint.DevolucionContext ctx) {
        System.out.println("dev: "+count_dev);
        if(count_dev==0){
            gencode_devolucion(ctx.getText());
        }else{
            count_dev--;
            System.out.println("no hago: "+ctx.getText());
        }
    }

    private void gencode_iteracion(String bucle) {
        try{
            if(cuenta_iter==0){
                cuenta_iter=contadorCadena(bucle,"fmientras");
            }
                if(!bucle.isEmpty()){

                    if(bucle.startsWith("mientras")){
                        String cond=bucle.substring(8,bucle.indexOf("hacer"));
                        gencode_espacios();
                        if(cond.contains("T")){
                            cond=cond.replace("T","true");
                        }else if (cond.contains("F")){
                            cond=cond.replace("F","false");
                        }
                        fichero.write("while"+cond);
                        bucle=bucle.substring(bucle.indexOf("hacer"),bucle.length());
                        gencode_iteracion(bucle);

                    }else if(bucle.startsWith("hacer")){
                        fichero.write("{\n");
                        aumentoTabulacion();
                        bucle=bucle.substring(5,bucle.length());
                        gencode_iteracion(bucle);

                    }else if(bucle.startsWith("fmientras")){
                        decrementoTabulacion();
                        gencode_espacios();
                        fichero.write("}\n");
                        bucle=bucle.substring(9,bucle.length());
                        gencode_iteracion(bucle);

                    }else if(bucle.startsWith("si")) {
                        //if dentro de mientras
                        String[] sigue = bucle.split("fsi");
                        int i = sigue.length - 1;
                        String si = bucle.substring(0, bucle.length() - sigue[i].length());
                        count_instr+=contadorCadena(si,";")-contadorCadena(si,"ruptura")-contadorCadena(si,"dev");
                        count_dev+=contadorCadena(si,"dev");
                        gencode_condicional(si);
                        bucle = bucle.substring(si.length(), bucle.length());
                        gencode_iteracion(bucle);

                    }else if(bucle.startsWith("dev")){
                        count_dev++;
                        gencode_espacios();
                        bucle=bucle.substring(3,bucle.length());
                        String[]res=bucle.split(";");
                        fichero.write("System.out.println("+res[0]+");\n");
                        bucle=bucle.substring(res[0].length()+1,bucle.length());
                        gencode_iteracion(bucle);

                    } else if(bucle.startsWith("ruptura")) {
                        //count_instr++;
                        gencode_espacios();
                        bucle=bucle.substring(8,bucle.length());
                        fichero.write("break;\n");

                        gencode_iteracion(bucle);
                    }else{

                        String[] instr = bucle.split(";");
                        String asig=instr[0]+";";
                        gencode_asignacion(asig);
                        bucle=bucle.substring(asig.length(),bucle.length());
                        count_instr++;
                        System.out.println(instr[0]+" -> "+count_instr);
                        gencode_iteracion(bucle);
                    }
                }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    private Integer contadorCadena(String sTexto, String sTextoBuscado){
        Integer res=0;
        while (sTexto.indexOf(sTextoBuscado) > -1) {
            sTexto = sTexto.substring(sTexto.indexOf(
                    sTextoBuscado)+sTextoBuscado.length(),sTexto.length());
            res++;
        }

        return res;
    }

    public void gencode_devolucion(String devo){
        try{
            if(devo.startsWith("dev")){
                gencode_espacios();
                fichero.write("System.out.println("+devo.substring(3,devo.length()-1)+");\n");
            }
        } catch (Exception e) {
            System.out.println("Error gencode_devolucion: error al intentar hacer dev "+e.toString());
        }
    }
}